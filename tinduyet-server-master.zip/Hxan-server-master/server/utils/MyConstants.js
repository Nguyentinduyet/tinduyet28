const MyConstants = {
    DB_SERVER: 'cluster0.fzwyn5c.mongodb.net',
    DB_USER: 'Vansang',
    DB_PASS: 'vansang',
    DB_DATABASE: 'Shoping_pet',
    EMAIL_USER: '', // Microsoft mail service
    EMAIL_PASS: '',
    JWT_SECRET: 'sang',
    JWT_EXPIRES: '10000000000000000', // in milliseconds
};
module.exports = MyConstants;